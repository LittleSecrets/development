$(function(){
    zfMyAdmin.selectModuleControllerAction();
}); 