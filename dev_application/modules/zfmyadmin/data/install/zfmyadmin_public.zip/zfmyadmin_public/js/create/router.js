$(function(){
    zfMyAdmin.selectModuleControllerAction(); 
}); 